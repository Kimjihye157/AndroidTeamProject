var express = require('express');
var router = express.Router();

const usersController = require("../controller/users");
const user = new usersController();

/* GET users listing. */
router.get('/', user.inqury);

module.exports = router;
