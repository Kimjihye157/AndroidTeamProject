package com.cookandroid.avoid_allergy;

import com.google.gson.annotations.SerializedName;

public class LoginRequest {

    @SerializedName("input_id")
    public String input_id;

    @SerializedName("input_pw")
    public String input_pw;

    public String getInput_id() {
        return input_id;
    }

    public String getInput_pw() {
        return input_pw;
    }

    public void setInput_id(String input_id) {
        this.input_id = input_id;
    }

    public void setInput_pw(String input_pw) {
        this.input_pw = input_pw;
    }

    public LoginRequest(String input_id, String input_pw) {
        this.input_id = input_id;
        this.input_pw = input_pw;
    }
}
