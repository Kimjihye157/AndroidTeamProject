package com.cookandroid.avoid_allergy;


import java.util.List;

//데이터 받아올 껍데기 정의
public class Model {
    //사용자 정보 테이블
    String user_id;
    String user_pw;
    String user_name;
    String user_addr;
    String user_num;

    //사용자 알레르기 정보 테이블
    List allergy_name;

    //사용자 정보 테이블 입력
    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getUser_pw() {
        return user_pw;
    }

    public void setUser_pw(String user_pw) {
        this.user_pw = user_pw;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getUser_addr() {
        return user_addr;
    }

    public void setUser_addr(String user_addr) {
        this.user_addr = user_addr;
    }

    public String getUser_num() {
        return user_num;
    }

    public void setUser_num(String user_num) {
        this.user_num = user_num;
    }

    //사용자 알레르기 정보 테이블 입력
    public List getAllergy_name() {
        return allergy_name;
    }

    public void setAllergy_name(List allergy_name) {
        this.allergy_name = allergy_name;
    }
}
