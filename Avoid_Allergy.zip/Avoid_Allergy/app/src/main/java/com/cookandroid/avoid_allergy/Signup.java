package com.cookandroid.avoid_allergy;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Signup extends AppCompatActivity {

    private List<String> allergies = new ArrayList<String>();

    EditText signup_id, signup_password, signup_name, signup_address, signup_num;
    TextView signup_allergy;
    Button  signup_signupBtn;
    CheckBox allergy_shrimp, allergy_nut, allergy_fork,
            allergy_milk, allergy_clam, allergy_fish,
            allergy_egg, allergy_peach, allergy_meat;

    private static final String TAG = "Signup";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signup);

        signup_id = (EditText) findViewById(R.id.signup_id);
        signup_password = (EditText) findViewById(R.id.signup_password);
        signup_name = (EditText) findViewById(R.id.signup_name);
        signup_address = (EditText) findViewById(R.id.signup_address);
        signup_num = (EditText) findViewById(R.id.signup_phoneNum);

        signup_allergy = (TextView) findViewById(R.id.signup_allergy);

        CheckBox allergy_shrimp = (CheckBox) findViewById(R.id.allergy_shrimp);
        CheckBox allergy_nut = (CheckBox) findViewById(R.id.allergy_nut);
        CheckBox allergy_fork = (CheckBox) findViewById(R.id.allergy_fork);
        CheckBox allergy_milk = (CheckBox) findViewById(R.id.allergy_milk);
        CheckBox allergy_clam = (CheckBox) findViewById(R.id.allergy_clam);
        CheckBox allergy_fish = (CheckBox) findViewById(R.id.allergy_fish);
        CheckBox allergy_egg = (CheckBox) findViewById(R.id.allergy_egg);
        CheckBox allergy_peach = (CheckBox) findViewById(R.id.allergy_peach);
        CheckBox allergy_meat = (CheckBox) findViewById(R.id.allergy_meat);

        signup_signupBtn = (Button) findViewById(R.id.signup_signupBtn);


        allergy_shrimp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (allergy_shrimp.isChecked()) {
                    allergies.add("새우");
                }

            }
        });
        allergy_nut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (allergy_nut.isChecked()) {
                    allergies.add("견과류");
                }
            }
        });
        allergy_fork.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (allergy_fork.isChecked()) {
                    allergies.add("돼지고기");
                }
            }
        });
        allergy_milk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (allergy_milk.isChecked()) {
                    allergies.add("우유");
                }
            }
        });
        allergy_clam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (allergy_clam.isChecked()) {
                    allergies.add("조개");
                }
            }
        });
        allergy_fish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (allergy_fish.isChecked()) {
                    allergies.add("고등어");
                }
            }
        });
        allergy_egg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (allergy_egg.isChecked()) {
                    allergies.add("계란");
                }
            }
        });
        allergy_peach.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (allergy_peach.isChecked()) {
                    allergies.add("복숭아");
                }
            }
        });
        allergy_meat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    if (allergy_meat.isChecked()) {
                    allergies.add("소고기");
                }
            }
        });

        signup_signupBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Model postingData = new Model();
                postingData.setUser_id(signup_id.getText().toString());
                postingData.setUser_pw(signup_password.getText().toString());
                postingData.setUser_name(signup_name.getText().toString());
                postingData.setUser_addr(signup_address.getText().toString());
                postingData.setUser_num(signup_num.getText().toString());
                postingData.setAllergy_name(allergies);

                Methods methods = Client.getRetrofitInstance().create(Methods.class);
                methods.postData(postingData).enqueue(new Callback<Model>() {
                    @Override
                    public void onResponse(Call<Model> call, Response<Model> response) {
                        if(response.isSuccessful()){
                            Model model = response.body();
                        }
                    }

                    @Override
                    public void onFailure(Call<Model> call, Throwable t) {

                    }
                });

                Intent intent  = new Intent(getApplicationContext(), Login.class);
                startActivity(intent);

            }
        });
    }
}