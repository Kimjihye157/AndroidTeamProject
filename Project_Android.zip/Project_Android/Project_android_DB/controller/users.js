const {request} = require("express");
const httpStatus = require("http-status-codes");
const pool = require("../middleware/DB");

class user {
    async inqury(req, res) {
        try {
            const user = await pool.query("select * from user");

            return res.send(user[0]);
        } catch (error) {
            return res.status(500).json(error);
        }
    }
}