var express = require('express');
var router = express.Router();

const userController = require("../controllers/user");
const user = new userController();

/* 회원가입 */
router.post("/:user_id", user.signup);

/* 회원 조회 */
router.get("/:user_id", user.search);

module.exports = router;
