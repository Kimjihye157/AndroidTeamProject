const { request } = require("express");
const httpStatus = require("http-status-codes");
const { add } = require("nodemon/lib/rules");
const pool = require("../middleware/db");

class user {
    async signup(req, res) {
        try {
            const user_id = req.body.user_id;
            const user_pw = req.body.user_pw;
            const user_name = req.body.user_name;
            const user_addr = req.body.user_addr;
            const user_num = req.body.user_num;

            await pool.query('insert into user(user_id, user_pw, user_name, user_addr, user_num) values(?, ?, ?, ?, ?)', [user_id, user_pw, user_name, user_addr, user_num])

            return res.status(httpStatus.OK).send("회원가입 완료")

        } catch (error) {
            return res.status(500).json(error);
        }
    }

    async search(req, res) {
        try {

            const user_id = req.params.user_id;
            
            const search = await pool.query('select * from user where user_id = ?', [user_id])

            return res.status(httpStatus.OK).send(search[0])

        } catch (error) {
            return res.status(500).json(error);
        }
    }
}

module.exports = user;