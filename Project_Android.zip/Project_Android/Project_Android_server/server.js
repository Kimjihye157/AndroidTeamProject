const express = require("express");
const app = express();

/* localhost:8080/ 접속시 나올 메시지 */
app.get("/", (request, response) => { 
  response.send(`<h1> 안드로이드 </h1>`);
});

/* localhost:8080/main 접속시 나올 메시지 */
app.get("/main", (request, response) => {  
  response.send(`
    <h1>Hello World</h1>
    <p>This is main page</p>
    `);
});

/* localhost:8080/ 혹은 localhost:3000/main 외의
get하지 않은 페이지 접속시 나올 메시지. */
app.use((request, response) => {
  response.send(`<h1>Sorry, page not found :(</h1>`);
});

/* 8080포트에서 서버 구동 */
app.listen(8080, () => {
  console.log("localhost:8080 에서 서버가 시작됩니다.");
});